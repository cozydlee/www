<template>
      <header>
            <v-app-bar
      app
      color
      width="100%"
    >
      <router-link to="/main"><h1 class="logo">백년가게 로고</h1></router-link>
      <nav>
				<h2 class="hidden">글로벌네비게이션영역</h2>
				<ul>
					<li><h3><router-link to="/main">사업소개</router-link></h3></li>
					<li><h3><router-link to="/sub">점포안내</router-link></h3></li>
				</ul>
      </nav>
          </v-app-bar>
    </header>
</template>

<style>
		header{overflow: hidden;
    padding: 0; border: 0; font-size: 100%;}

    .logo{color: #f0f0f0;
    text-decoration: none;
    background: url(../assets/logo2.png) no-repeat;
    text-indent: -1000px;
    display: block;
    width: 300px;
    height: 212px;
    float: left;
    transform: scale(.4);
    }

		nav{float: right;}
		nav ul{overflow: hidden;}
		nav ul li{float: left; margin-right: 15px; margin-top: 20px; font-size: 1.2rem;}

    .v-toolbar__content, .v-toolbar__extension {justify-content: space-around;}

</style>

<script>
export default {
    props:(`plogo`)
}
</script>