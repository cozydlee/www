<template>
  <footer>
      <p class="copy">카피라이터입니다</p>
  </footer>
</template>

<style>
     .copy{color: #fff; font-size: 16px;
        background: #333; padding: 15px 0; }
</style>

<script>
export default {
  
}
</script>