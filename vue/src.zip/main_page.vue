<template lang="html">
  <div class="box1">
    <div class="title">
      <h2>사업소개</h2>
    </div>
    <article>
      <h2><i class="fa-solid fa-store"></i> 백년가게란?</h2>
      <ul>
        <li>소상공인의 롤모델이 되어주실</li>
        <li>업력 30년 이상 사장님이시라면 지금 신청하세요!</li>
      </ul>
      <ul class="piclist">
        <li><img src="./assets/pic1.jpg" alt="pic1"></li>
        <li><img src="./assets/pic2.jpg" alt="pic2"></li>
        <li><img src="./assets/pic3.jpg" alt="pic3"></li>
      </ul>
      <p>30년 이상 명맥을 유지하면서도 오래도록 고객의 꾸준한 사랑을 받아온 점포 가운데, 중소벤처기업부에서 그 우수성과 성장 가능성을 높게 평가 받아 공식 인증받은 점포입니다.</p>
    </article>
    <div class="feature3-component mini-spacer">
      <v-container class="position-relative">
        <v-row>
          <v-col cols="12" lg="10">
            <v-img
              :src="require('./assets/logo2.png')"
              alt="feature"
              class="rounded"
            />
          </v-col>
          <v-col cols="12" md="7" lg="5" class="feature3-card">
            <v-card class="card-shadow">
              <v-card-text>
                <div class="pa-10 text-center">
                  <v-chip small color="info" text-color="white">
                    Feature 3
                  </v-chip>
                  <h3 class="feature3-title font-weight-medium">
                    The New way of Making Your Website in mins
                  </h3>
                  <p>
                    You can relay on our amazing features list and also our
                    customer services will be great experience. You will love it
                    for sure.
                  </p>
                  <v-btn
                    color="error"
                    class="btn-custom-lg linking mt-10 btn-arrow"
                    nuxt
                    large
                    to="/"
                    elevation="0"
                  >
                    <span>Explore More</span>
                    <i class="mdi mdi-arrow-right"></i>
                  </v-btn>
                </div>
              </v-card-text>
            </v-card>
            <v-card class="card-shadow">
              <v-card-text>
                <div class="pa-10 text-center">
                  <v-chip small color="info" text-color="white">
                    Feature 3
                  </v-chip>
                  <h3 class="feature3-title font-weight-medium">
                    The New way of Making Your Website in mins
                  </h3>
                  <p>
                    You can relay on our amazing features list and also our
                    customer services will be great experience. You will love it
                    for sure.
                  </p>
                  <v-btn
                    color="error"
                    class="btn-custom-lg linking mt-10 btn-arrow"
                    nuxt
                    large
                    to="/"
                    elevation="0"
                  >
                    <span>Explore More</span>
                    <i class="mdi mdi-arrow-right"></i>
                  </v-btn>
                </div>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    // 라우터 함수로 이동할 때는 $router 글로벌 객체에 이동할 주소 넣어줌
    fnSubPage() {
      this.$router.push('/sub')
    }
  }
}
</script>

<style>
  .title{padding: 200px; box-sizing: border-box; background: url(assets/main1.jpg) center 50%;}
  article{padding: 0 20px; position: relative;}
  article h2{color: #333; margin: 2% 0; letter-spacing: normal;}
  ul{color: #666;}
  ul li{margin-bottom: 5px;}
  article p{font-size: 1.5rem; padding-right: 30%; text-align: left; margin: 40px;line-height: 2rem;}

  .piclist {overflow: hidden; margin: 20px 76px;}
  .piclist::before{content: ''; background: #498fcc; position:absolute; height: 100px; width: 100%; left: 0; top: 252px;
  z-index: -1;} 
  .piclist li{float: left; overflow: hidden; height: 280px; width: 33.33%;}
  .piclist li img{width: 400px; margin: 25px;}

  .feature3-component {
  position: relative;
  margin: 0 20px;
}

.feature3-card {
  position: absolute;
  top: 17%;
  right: 0;
}

.feature3-title {
    font-size: 24px;
    line-height: 30px;
    margin: 20px 0 15px;
  }

@media (min-width: 768px) and (max-width: 991px) {
  .feature3-card {
    left: 0;
    right: 0;
    margin: 0 auto;
    top: 50%;
  }
}

@media (max-width: 767px) {
  .feature3-card {
    position: relative;
  }
}

.v-card {
  margin: 50px;
  transition: all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
}
.v-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 2px 30px rgba(0, 0, 0, 0.1);
}

.v-btn {
  transition: all 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
}
.v-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 2px 30px rgba(0, 0, 0, 0.1);
}

</style>