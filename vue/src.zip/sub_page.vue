<template lang="html">
  <div class="box2">
    <div class="title2">
      <h2>점포안내</h2>
    </div>
          <div v-for="(x) in oneromms" :key="x.id">
       <img :src="x.image" alt="" class="rimg">
       <h4>{{ (x.id+1) + '.' + x.title }}</h4>
       <p>{{ 'price : ' + x.price }}</p>
       <p>{{ x.content }}</p>
   </div> 
  </div>
</template>

<script>
import jdata from './oneroom.json';

export default {
  methods: {
    // 라우터 함수로 이동할 때는 $router 글로벌 객체에 이동할 주소 넣어줌
    fnMainPage() {
      this.$router.push('/main')
    }
  },
    name : 'app',
  data(){
    return{
    vname:`홍길동`,
    cnt:1,
    classname:`btn`,
    btnstyle:`background:red; color:#fff; width:200px; padding:15px 0`,
    oneromms : jdata
    }
  },
    methods2: {
    append: function(){
      this.cnt++;
    }
  }
}
</script>

<style>
  .title2{padding: 200px; box-sizing: border-box; background: url(assets/main2.jpg) center 50%;}
</style>